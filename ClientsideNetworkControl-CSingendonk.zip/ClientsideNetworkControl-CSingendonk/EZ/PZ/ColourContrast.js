(function () {
  // ---------- Debounce Utility ----------
  function debounce(func, wait, immediate) {
    let timeout;
    return function () {
      const context = this,
        args = arguments;
      const later = function () {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      const callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  }

  // ---------- Color Utilities Module ----------
  const ColorUtils = {
    // Convert RGB values to HEX.
    rgbToHex: function (r, g, b) {
      return (
        "#" +
        [r, g, b]
          .map((x) => {
            const hex = x.toString(16);
            return hex.length === 1 ? "0" + hex : hex;
          })
          .join("")
      );
    },

    // Convert HEX to RGB array.
    hexToRgb: function (hex) {
      hex = hex.replace("#", "");
      if (hex.length === 3) {
        hex = hex
          .split("")
          .map((c) => c + c)
          .join("");
      }
      const num = parseInt(hex, 16);
      return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
    },

    // Convert RGB to HSL.
    // Returns [h, s, l] where h is in [0, 360) and s, l are in [0, 100]
    rgbToHsl: function (r, g, b) {
      r /= 255;
      g /= 255;
      b /= 255;
      const max = Math.max(r, g, b),
        min = Math.min(r, g, b);
      let h, s, l = (max + min) / 2;
      if (max === min) {
        h = s = 0; // achromatic
      } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r:
            h = (g - b) / d + (g < b ? 6 : 0);
            break;
          case g:
            h = (b - r) / d + 2;
            break;
          case b:
            h = (r - g) / d + 4;
            break;
        }
        h *= 60;
      }
      return [h, s * 100, l * 100];
    },

    // Convert HSL to RGB array.
    hslToRgb: function (h, s, l) {
      s /= 100;
      l /= 100;
      const c = (1 - Math.abs(2 * l - 1)) * s;
      const x = c * (1 - Math.abs((h / 60) % 2 - 1));
      const m = l - c / 2;
      let r, g, b;
      if (h < 60) {
        r = c;
        g = x;
        b = 0;
      } else if (h < 120) {
        r = x;
        g = c;
        b = 0;
      } else if (h < 180) {
        r = 0;
        g = c;
        b = x;
      } else if (h < 240) {
        r = 0;
        g = x;
        b = c;
      } else if (h < 300) {
        r = x;
        g = 0;
        b = c;
      } else {
        r = c;
        g = 0;
        b = x;
      }
      r = Math.round((r + m) * 255);
      g = Math.round((g + m) * 255);
      b = Math.round((b + m) * 255);
      return [r, g, b];
    },

    // Calculate relative luminance of a HEX color.
    getLuminance: function (hexColor) {
      const [r, g, b] = this.hexToRgb(hexColor);
      const [R, G, B] = [r, g, b].map((v) => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      });
      return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    },

    // Calculate contrast ratio between two HEX colors.
    getContrastRatio: function (hex1, hex2) {
      const L1 = this.getLuminance(hex1);
      const L2 = this.getLuminance(hex2);
      const brighter = Math.max(L1, L2);
      const darker = Math.min(L1, L2);
      return (brighter + 0.05) / (darker + 0.05);
    },

    // Return the complementary color by rotating the hue 180°.
    getComplementaryColor: function (hexColor) {
      const [r, g, b] = this.hexToRgb(hexColor);
      let [h, s, l] = this.rgbToHsl(r, g, b);
      h = (h + 180) % 360;
      const [newR, newG, newB] = this.hslToRgb(h, s, l);
      return this.rgbToHex(newR, newG, newB);
    },

    // Get a brightness-based contrasting color candidate.
    getBrightnessContrastCandidate: function (hexColor) {
      const [r, g, b] = this.hexToRgb(hexColor);
      let [h, s, l] = this.rgbToHsl(r, g, b);
      // For light backgrounds, darken; for dark, lighten.
      l = this.getLuminance(hexColor) > 0.5 ? Math.max(0, l - 40) : Math.min(100, l + 40);
      return this.rgbToHex(...this.hslToRgb(h, s, l));
    },

    // Adjust candidate text color's lightness until desired contrast ratio is met.
    adjustContrast: function (candidateHex, bgHex, threshold) {
      let [h, s, l] = this.rgbToHsl(...this.hexToRgb(candidateHex));
      let contrast = this.getContrastRatio(bgHex, candidateHex);
      let iterations = 0;
      const bgLuminance = this.getLuminance(bgHex);
      // Adjust in steps of 5% until threshold met or 20 iterations reached.
      while (contrast < threshold && iterations < 20) {
        l = bgLuminance > 0.5 ? Math.max(0, l - 5) : Math.min(100, l + 5);
        candidateHex = this.rgbToHex(...this.hslToRgb(h, s, l));
        contrast = this.getContrastRatio(bgHex, candidateHex);
        iterations++;
      }
      return candidateHex;
    },

    // Parse an input color string to HEX.
    // Supports: hex (#abc, #aabbcc), rgb/rgba, hsl.
    parseColor: function (input) {
      input = input.trim();
      // HEX formats
      if (/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(input)) {
        return input;
      }
      // rgb or rgba (ignoring alpha)
      if (/^rgba?\(/i.test(input)) {
        const rgbValues = input.match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
        if (rgbValues) {
          const r = parseInt(rgbValues[1], 10);
          const g = parseInt(rgbValues[2], 10);
          const b = parseInt(rgbValues[3], 10);
          return this.rgbToHex(r, g, b);
        }
      }
      // hsl format
      if (/^hsl\(/i.test(input)) {
        const hslValues = input.match(/hsl\(\s*(\d+)[,\s]+(\d+)%[,\s]+(\d+)%/i);
        if (hslValues) {
          const h = parseInt(hslValues[1], 10);
          const s = parseInt(hslValues[2], 10);
          const l = parseInt(hslValues[3], 10);
          const [r, g, b] = this.hslToRgb(h, s, l);
          return this.rgbToHex(r, g, b);
        }
      }
      console.error("Could not parse color:", input);
      return null;
    }
  };

  // ---------- Main Color Update Function ----------
  // Options:
  //   contrastMethod: 'complementary' or 'brightness'
  //   contrastThreshold: desired contrast ratio (default: 4.5)
  function updateColors(options = {}) {
    const { contrastMethod = "complementary", contrastThreshold = 4.5 } = options;
    const inputColor = document.querySelector("#uic").value;
    let hexColor = ColorUtils.parseColor(inputColor);
    if (!hexColor) {
      hexColor = "#000000"; // fallback to black
    }
    // Apply background color.
    document.body.style.backgroundColor = hexColor;

    // Choose candidate based on selected method.
    let candidateTextColor =
      contrastMethod === "brightness"
        ? ColorUtils.getBrightnessContrastCandidate(hexColor)
        : ColorUtils.getComplementaryColor(hexColor);

    // Adjust candidate until contrast threshold is met.
    candidateTextColor = ColorUtils.adjustContrast(candidateTextColor, hexColor, contrastThreshold);
    // Apply text color.
    document.body.style.color = candidateTextColor;

    console.log(
      "Background:",
      hexColor,
      "Text:",
      candidateTextColor,
      "Contrast Ratio:",
      ColorUtils.getContrastRatio(hexColor, candidateTextColor)
    );
  }
  const debouncedUpdate = debounce(() => updateColors({ contrastMethod: "complementary", contrastThreshold: 4.5 }), 300);
  document.querySelector("#uic").addEventListener("input", debouncedUpdate);

  updateColors({ contrastMethod: "complementary", contrastThreshold: 4.5 });
})();
