Hello =)

Please ensure you credit the original source of this repository!
Instead of cloning and reimagining a copy from scratch, add to this base on github at https://github.com/CSingendonk/ClientsideNetworkControl/tree/CSingendonk
Your contributions will be clearly marked as your own individual property and will remain subject to your licensing terms as agreed upon.
We all benefit from sharing, when reciprocated. 


if you are seeing thiss because you just cloned this or whatever without any regard to the creator(s), and are going to or are using it without any notification or attribution to your source then fuck you.
otherwise.. 
  
  
THANK YOU and welcome!
for more info see https://github.com/CSingendonk/ClientsideNetworkControl/tree/CSingendonk
