## © 2024, 2025 - Chris Singendonk All Rights# ALL RIGHTS RESERVED
**see below for project info**
- **As per GitHub**
> “However, without a license, the default copyright laws
> apply, meaning that you retain all rights to your source code and no one
> may reproduce, distribute, or create derivative works from your work.”

*Unfortunately This work is not licensed for reproduction or modification* **unless**:
 - You have been granted explicit written approval from the author/copyright holder. ,
 > 
   **OR**
 - you are a contributing collaborator on the project.

## ZERO DATA COLLECTION

### NO COOKIES, TRACKERS, OR DATA COLLECTION
- The script is fully static and works **offline**—though it can be served from anywhere.
  - Ask for instructions on how to integrate into a node.js or other server environments. (it only takes like 2 lines of code legit)
- **Privacy by Default:** No data from the program or your usage of it is externally logged, stored, or transmitted off your device.
  - your browser will continue to track you any way they can,
    - <sup>like with built-in code residing on your device and served from chrome:// or about:// url via VMs and serviceworkers etc.,</sup>
    - <sup>CNC can help detect when that is happening, and give you opportunity to block the transfer of dta outbound from any site you activate it on.</sup>
- **Local Storage:** Can be disabled entirely (note: logs won’t persist between sessions or tabs).

---

## BASE BLOCKING FUNCTIONALITY (< 5000 CHARS)
- **Included:** XHR, BGSW, WS, HTTP.

---

## UI, CSS, HTML, AND JS MODULES IN ONE FILE
- The js object-modules produce the html and css code needed for the ui to render when a call to the coresponding api is made using the object-modules rules programatic 

---
## Usage & Integration

### Manual Usage
- **Embed:** Include the single script via a `<script>` tag.
- **Auto-Initialization:** The IIFE auto-initializes upon loading.
- **Dynamic UI:** The Toaster and LogPanel elements are appended at runtime.
- **API:** Use the exposed `DOMLogger` API for programmatic interaction.

### Extension Usage
1. **Download:** Get the `.crx` file from the repository’s release.
2. **Convert:** Change the file extension from `.crx` to `.zip`.
3. **Load:** Navigate to `chrome://extensions` in Chrome, enable Developer Mode, and drag & drop the `.zip` file into the browser.

> **Note:** The manifest and injection logic in the zip use Chrome Manifest V3. The script is injected directly into the page’s DOM (not in a sandboxed content script) to access the page’s internal scope. The public API can be used by the extension’s background, content, or popup scopes via emissions, messages, and workers, and can also access extension APIs via content scripts.

[View core.js on GitHub](https://github.com/CSingendonk/ClientsideNetworkControl/blob/CSingendonk/core.js)  
[View initLogs.js on GitHub](https://github.com/CSingendonk/ClientsideNetworkControl/blob/CSingendonk/initLogs.js)
## UI Components

### Toaster
- Used for linking and displaying customizable toasts locally.

### LogPanel
- A custom HTML element that provides:
  - A versatile header for repositioning, collapsing, minimizing, maximizing, hiding, or removing the panel.
  - Options for setting colour themes and managing log entries (export, import, persist, clear).
  - Floating behavior that adapts dynamically to ensure clear rendering without affecting external CSS/HTML.

![image](https://github.com/user-attachments/assets/c8cb0afe-ef8e-4817-a3a6-e5c1be6455fc)
![image](https://github.com/user-attachments/assets/3b55d69f-26dd-4ff7-b30c-18ea9c06deec)

![image](https://github.com/user-attachments/assets/f13754e8-4f08-4da8-8dfa-82335c05cb53)

![image](https://github.com/user-attachments/assets/fccf789a-0771-41a0-be8c-d9351df77488)
![image](https://github.com/user-attachments/assets/945e5cc5-a1e0-414e-a268-86f679bdc0e8)

![image](https://github.com/user-attachments/assets/da609579-8c5a-4f85-9f06-b6427f1c64b3)


![image](https://github.com/user-attachments/assets/87a60ed3-07f0-45d7-b921-751b19dee5a8)

![image](https://github.com/user-attachments/assets/7e6824f3-d053-4e18-8b8c-ef5f76037561)





#### See my [HTMLPanels](https://github.com/CSingendonk/htmlpanels) and [Whoops](https://github.com/CSingendonk/whoops) repositories for earlier drafts and proof of concept drafts.
 -  [HTMLPanels](https://github.com/CSingendonk/htmlpanels):
 - - Here you can find:
   -  Early in-page [console](https://csingendonk.github.io/htmlpanels/ui.html) HTMLElement test,
   - Prototypes of custom HTML elements.
   - And some silly games written with these same parameters of independence.
---

# HONORING COPYRIGHT & RESTRICTIONS IN COLLABORATIONS

Unauthorized usage, reproduction, modification, or distribution of unlicensed original works—whether in whole or in part—violates copyright.

**Consider**:

Imagine spending countless hours designing and building a car. Collaboration is vital, but what if others take your blueprint, improve it behind closed doors, and leave you out? You miss out on valuable learning and see no benefit for your effort. They lose out on your contributions to further the work.This is why **permission and attribution** matter.

---

## CONTACT FOR APPROVAL
To use, modify, or build upon this work, you **must first obtain explicit written permission** from the author. Collaboration is welcome when mutual understanding and respect are upheld.

**Contact:** [https://github.com/csingendonk](https://github.com/csingendonk)  
**If in doubt—ask first.**

## OBSOLETE DRAFT

This is a draft copy of the complete code from a previous point in time and state.


 Reserved.

*This work is **NOT LICENSED** for public or private use, modification, distribution, reproduction, or creation of derivative works **without explicit written approval from the author**. By default, **you may not use, modify, or distribute any part of this work** unless you have received direct permission from the copyright holder.*

> **Note:** Any API or code not defined within this project is assumed to be part of a standard web API, which is typically documented in official web development resources. The scripts rely on base web APIs, each subject to its respective owner’s copyright and/or licensing conditions.  
> Any breach of contract, law, or other official restrictions, regulations, stipulations, or similar legalities arising from the use of this work is entirely upon the user.



---

## ZERO DATA COLLECTION

### NO COOKIES, TRACKERS, OR DATA COLLECTION
- The script is fully static and works **offline**—though it can be served from anywhere.
- **Privacy by Default:** No data is logged, stored, or transmitted externally.
- **Local Storage:** Can be disabled entirely (note: logs won’t persist between sessions or tabs).
- **Optional Remote Sync:** You may set up remote syncing and exporting if desired.

See [Release 1](https://github.com/CSingendonk/ClientsideNetworkControl/releases/tag/xhr) for a demo of the network interception concept in action.

---

## BASE BLOCKING FUNCTIONALITY (< 5000 CHARS)
- **Included:** XHR, BGSW, WS, HTTP.

---

## UI, CSS, HTML, AND JS MODULES IN ONE FILE
- The entire project is under 3000 lines of code.

---

# HONORING COPYRIGHT & RESTRICTIONS IN COLLABORATIONS

Unauthorized usage, reproduction, modification, or distribution of unlicensed original works—whether in whole or in part—violates copyright.

**Consider**:

Imagine spending countless hours designing and building a car. Collaboration is vital, but what if others take your blueprint, improve it behind closed doors, and leave you out? You miss out on valuable learning and see no benefit for your effort. They lose out on your contributions to further the work.This is why **permission and attribution** matter.

---

## CONTACT FOR APPROVAL
To use, modify, or build upon this work, you **must first obtain explicit written permission** from the author. Collaboration is welcome when mutual understanding and respect are upheld.

**Contact:** [https://github.com/csingendonk](https://github.com/csingendonk)  
**If in doubt—ask first.**
![image](https://github.com/user-attachments/assets/871f0afa-fa94-4471-bb34-9bd7050da1c1)

## OBSOLETE DRAFT

This is a draft copy of the complete code from a previous point in time and state.
